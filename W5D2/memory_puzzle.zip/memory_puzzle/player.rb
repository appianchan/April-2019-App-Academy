require_relative "board.rb"
class Player

    attr_accessor :name, :score

    def initialize(name)
        @name = name
        @score = 0
    end
    
    

end