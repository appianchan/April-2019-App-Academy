DROP TABLE IF EXISTS cattoys;
DROP TABLE IF EXISTS cats;
DROP TABLE IF EXISTS toys;

CREATE TABLE cats (
    id serial primary key,
    name character varying(20),
    breed character varying(20),
    color character varying(20)
);

CREATE TABLE toys (
    id serial primary key,
    price decimal,
    name character varying (50),
    color character varying (20)
);

CREATE TABLE cattoys (
    id serial primary key,
    cat_id integer NOT NULL,
    toy_id integer NOT NULL,
    foreign key (cat_id) references cats(id),
    foreign key (toy_id) references toys(id)
);

INSERT INTO cats
    (name, breed, color)
VALUES
    ('Smudge', 'Mancoon', 'red'),
    ('Toco', 'Tabby', 'black'),
    ('Brownie', 'Siamese', 'hairless'),
    ('Smokey', 'alleycat', 'orange'),
    ('Bingo', 'bobcat', 'spotted')
    ;

INSERT INTO toys (price, name, color)
VALUES
    (.83, 'leggos', 'multicolored'), 
    (2.97, 'ball', 'purple'),
    (5.01, 'plushie', 'brown'),
    (1.25, 'RC car', 'green'),
    (50, 'diamond collar', 'red'),
    (75, 'beebee gun', 'black')
    ;

INSERT INTO cattoys (cat_id, toy_id)
VALUES
    ((SELECT id FROM cats WHERE name = 'Smudge'), (SELECT id FROM toys WHERE name = 'leggos')),
    ((SELECT id FROM cats WHERE name = 'Toco'), (SELECT id FROM toys WHERE name = 'ball')),
    ((SELECT id FROM cats WHERE name = 'Brownie'), (SELECT id FROM toys WHERE name = 'plushie')),
    ((SELECT id FROM cats WHERE name = 'Smokey'), (SELECT id FROM toys WHERE name = 'RC car')),
    ((SELECT id FROM cats WHERE name = 'Bingo'), (SELECT id FROM toys WHERE name = 'diamond collar'))
    
    ;