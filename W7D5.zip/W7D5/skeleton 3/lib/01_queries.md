# Try running the following queries and see how the cost differs from when you had a smaller database:

# Find all of the breeds for the cats named 'Noel'
EXPLAIN ANALYZE
SELECT breed
FROM cats
WHERE cats.name = 'Noel';

# Find all the toys that belong to the cat named 'Freyja'
    EXPLAIN ANALYZE
    SELECT toys.name
    FROM toys
    JOIN 
    cattoys ON cattoys.toy_id = toys.id
    JOIN
    cats ON cats.id = cattoys.cat_id
    WHERE cats.name = 'Freyja';

# Find all the toys and cats that are the color 'Red'

    EXPLAIN ANALYZE
     SELECT toys.name, cats.name
    FROM toys
    JOIN 
    cattoys ON cattoys.toy_id = toys.id
    JOIN
    cats ON cats.id = cattoys.cat_id
    WHERE cats.color = 'Red' OR toys.color = 'Red';
# Find all the toys that belong to the cats with the breed of 'British Shorthair'


    EXPLAIN ANALYZE
     SELECT toys.name
    FROM toys
    JOIN 
    cattoys ON cattoys.toy_id = toys.id
    JOIN
    cats ON cats.id = cattoys.cat_id
    WHERE cats.breed = 'British Shorthair';
# Find all the toys with a price of less than 10.


EXPLAIN ANALYZE
SELECT name
FROM
toys
WHERE price < 10;